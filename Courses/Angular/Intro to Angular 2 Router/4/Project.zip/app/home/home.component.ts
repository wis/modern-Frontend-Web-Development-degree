import {Component} from "@angular/core";
@Component({
    template: `
I'm a home component
`
})
export class HomeComponent{}
