import {Component} from "@angular/core";
@Component({
    template:`
This is a contacts component
`
})
export class ContactsComponent{}